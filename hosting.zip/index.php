<?php
    define('IN_SYS', true);
    require_once ("core.php");
?>
<?php include ("include/header.php"); ?>

<div class="container">
    <div class="jumbotron">
        <h3>GEORGIA.EU.ORG</h3>
        <p>პროფესიონალური ვებ ჰოსტინგი ...</p>
        <p><a class="btn btn-primary" href="register.php" role="button">რეგისტრაცია &raquo;</a></p>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <h2>რა არის ეს?</h2>
            <p>ჩვენი სერვისი არის სისტემა, რომელიც საშუალებას გაძლევთ შექმნათ საკმაოდ მძლავრი და ფუნქციონალური ვებსაიტები პირდაპირ თქვენი სმარტფონიდან სრულიად უფასოდ.</p>
        </div>
        <div class="col-md-6">
            <p><img src="assets/images/website.jpg" alt="server" class="img-rounded" style="width:100%;"></p>
        </div>
    </div>
</div>

<?php include ("include/footer.php"); ?>
