<?php
    define('IN_SYS', true);
    require_once "core.php";
    $security_id = md5(rand(6000, getrandmax()));
    $title = $title . ' - ' . I18N('register');
?>
<?php include ("include/header.php"); ?>

    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title"><?php echo I18N('signup_free_hosting'); ?></h3>
            </div>
            <div class="panel-body">
                <form class="form-horizontal" role="form" method=post action="//order.<?php echo $domain; ?>/register.php">
                    <input type="hidden" name="plan_name" value="free webhosting">
                    <div class="form-group">
                        <label for="inputUsername" class="col-sm-4 control-label"><?php echo I18N('subdomain'); ?></label>
                        <div class="col-sm-5">
                            <input type="text" class="form-control" name="username" id="inputUsername" pattern="[a-z0-9]{4,15}" placeholder="<?php echo I18N('input_subdomain'); ?>" value="<?php if (isset($_GET['username'])) {echo $_GET['username'];}?>" required>
                        </div>
                    </div>
<hr>
                    <div class="form-group">
                        <label for="inputPassword" class="col-sm-4 control-label"><?php echo I18N('password'); ?></label>
                        <div class="col-sm-5">
                            <input type="password" class="form-control" name="password" id="inputPassword" pattern=".{6,15}" placeholder="<?php echo I18N('input_password'); ?>" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputEmail" class="col-sm-4 control-label"><?php echo I18N('email'); ?></label>
                        <div class="col-sm-5">
                            <input type="email" class="form-control" name="email" id="inputEmail" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" placeholder="<?php echo I18N('input_email'); ?>" value="<?php if (isset($_GET['email'])) {echo $_GET['email'];}?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputID" class="col-sm-4 control-label"><?php echo I18N('security_code'); ?></label>
                        <div class="col-sm-5">
                            <img width="90px" height="25px" src="/security_code.php?id=<?php echo $security_id; ?>">
                            <input type="hidden" name="id" class="form-control" id="inputID" value="<?php echo $security_id; ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputSecurityCode" class="col-sm-4 control-label"><?php echo I18N('input_security_code'); ?></label>
                        <div class="col-sm-5">
                            <input type="text" class="form-control" name="number" id="inputSecurityCode" pattern=".{4,6}" placeholder="<?php echo I18N('input_security_code_above'); ?>" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-4 col-sm-6">
                            <button type="submit" name="submit" class="btn btn-default"><?php echo I18N('register'); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php include "include/footer.php";?>
